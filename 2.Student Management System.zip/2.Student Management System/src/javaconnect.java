/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author MSI PC
 */  
import java.sql.*;
import javax.swing.*;

public class javaconnect {
    Connection conn = null;
    
    public static Connection connectDB(){
        try{
            Class.forName("org.sqlite.JDBC");
            //Connection conn = DriverManager.getConnection("jdbc:sqlite:H:\\1.Education\\Academic\\2.1\\ManagementSQLite\\Database1.sqlite");
            Connection conn = DriverManager.getConnection("jdbc:sqlite:H:\\1.Education\\Academic\\2.1\\SD Project\\Project\\SMS.sqlite");
            //JOptionPane.showMessageDialog(null,"Welcome to the Student management System");
            
            return conn;
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
        
        return null;
    }
}
